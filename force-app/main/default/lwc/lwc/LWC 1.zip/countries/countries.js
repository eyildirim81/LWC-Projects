import { LightningElement } from 'lwc';

export default class Countries extends LightningElement {
    countries = [
        "United States",
        "United Arab Emirates",
        "India",
        "Singapore",
        "Turkey",
        "Malaysia",
        "Japan"
    ];
    
}